---
title: "Multi-Res Image"
description: "Projects a geo-referenced multi-resolution image tile map into the scene. The concept is the same as the Google Maps style pan/zoom satellite imagery."
image: "multires2.png"
parameters:
  - name: "Geo File"
    description: "Path to the geo-referenced map tiles."
---
