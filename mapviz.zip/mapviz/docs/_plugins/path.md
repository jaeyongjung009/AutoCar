---
title: "Path"
description: "Projects [nav_msgs::Path](http://docs.ros.org/api/nav_msgs/html/msg/Path.html) message data into the scene."
image: ""
parameters:
  - name: "Topic"
    description: "The path topic"
---
