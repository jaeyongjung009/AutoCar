---
title: "Move Base"
description: "Allows the user to send goals to [move_base](wiki.ros.org/move_base)."
image: ""
parameters:
---
