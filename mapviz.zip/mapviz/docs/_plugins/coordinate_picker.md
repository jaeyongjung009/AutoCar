---
title: "Coordinate Picker"
description: "Transforms coordinates of clicked points on the map to a specified frame. The most recent coordinate is placed on the clipboard, and a list of coordinates is displayed in the GUI."
image: "screenshot_coordinate_picker.png"
parameters:
  - name: frame
    description: "Coordinate frame into which to transform the clicked point"
---
