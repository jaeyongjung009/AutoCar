---
title: "Measuring"
description: "Measure distance on the canvas with the mouse."
image: ""
parameters:
---
