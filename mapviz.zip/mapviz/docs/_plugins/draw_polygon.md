---
title: "Draw Polygon"
description: "Draw a polygon on the canvas and publish to a topic."
image: ""
parameters:
---
