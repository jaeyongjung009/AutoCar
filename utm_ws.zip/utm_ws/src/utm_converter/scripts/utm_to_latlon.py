#!/usr/bin/env python

import rospy
from pyproj import Proj, transform

def utm_to_latlon(easting, northing, zone_number, zone_letter):
    # UTM 좌표계 정의 (Zone에 따라 다름)
    utm_proj = Proj(proj='utm', zone=zone_number, ellps='WGS84', south=(zone_letter < 'N'))
    lat, lon = transform(utm_proj, Proj(proj='latlong', datum='WGS84'), easting, northing)
    return lat, lon

if __name__ == '__main__':
    rospy.init_node('utm_to_latlon_converter')

    # 예시 UTM 좌표
    easting = 403122.0264969893
    northing = 4129106.3241630234
    zone_number = 52  # UTM 존 번호 (적절히 수정)
    zone_letter = 'N' # UTM 존 레터 (적절히 수정)

    lat, lon = utm_to_latlon(easting, northing, zone_number, zone_letter)
    rospy.loginfo(f"Latitude: {lat}, Longitude: {lon}")
