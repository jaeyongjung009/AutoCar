// /home/jjuuoo/catkin_ws/src/GPS_Package/gps_odom/include/gps_odom/OdomData.h

#ifndef GPS_ODOM_ODOM_DATA_H
#define GPS_ODOM_ODOM_DATA_H

class OdomData {
public:
    OdomData(double x, double y);
    
    double getX() const;
    double getY() const;

private:
    double x_;
    double y_;
};

#endif // GPS_ODOM_ODOM_DATA_H

