// /home/jjuuoo/catkin_ws/src/GPS_Package/two_gps_h_angle/include/two_gps_h_angle/GPSData.h

#ifndef TWO_GPS_H_ANGLE_GPS_DATA_H
#define TWO_GPS_H_ANGLE_GPS_DATA_H

#include <iostream>

class GPSData {
public:
    GPSData(double latitude, double longitude);
    
    double getLatitude() const;
    double getLongitude() const;

    void display() const;

private:
    double latitude_;
    double longitude_;
};

#endif // TWO_GPS_H_ANGLE_GPS_DATA_H

