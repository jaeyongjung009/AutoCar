#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <geometry_msgs/Twist.h>
#include <tf/tf.h>

class VelocityEstimator {
public:
    VelocityEstimator() {
        // Initialize ROS node handle and subscriber
        nh_ = ros::NodeHandle("~");
        imu_sub_ = nh_.subscribe("/imu/data", 10, &VelocityEstimator::imuCallback, this);
        velocity_pub_ = nh_.advertise<geometry_msgs::Twist>("current_velocity", 10);
        
        // Initialize velocity and time
        current_velocity_.linear.x = 0.0;
        current_velocity_.linear.y = 0.0;
        current_velocity_.linear.z = 0.0;
        last_time_ = ros::Time::now();
    }

    void imuCallback(const sensor_msgs::Imu::ConstPtr& msg) {
        // Compute delta time
        ros::Time current_time = ros::Time::now();
        double dt = (current_time - last_time_).toSec();
        last_time_ = current_time;

        // Extract linear acceleration from IMU data
        double ax = msg->linear_acceleration.x;
        double ay = msg->linear_acceleration.y;
        double az = msg->linear_acceleration.z;

        // Integrate acceleration to get velocity (m/s)
        current_velocity_.linear.x += ax * dt;
        current_velocity_.linear.y += ay * dt;
        current_velocity_.linear.z += az * dt;

        // Publish the current velocity
        velocity_pub_.publish(current_velocity_);
    }

private:
    ros::NodeHandle nh_;
    ros::Subscriber imu_sub_;
    ros::Publisher velocity_pub_;
    geometry_msgs::Twist current_velocity_;
    ros::Time last_time_;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "velocity_estimator");
    VelocityEstimator velocity_estimator;
    ros::spin();
    return 0;
}
