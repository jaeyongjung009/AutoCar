#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>

class ImuToOdom
{
public:
    ImuToOdom()
    {
        // Initialize ROS node handle
        nh_ = ros::NodeHandle("~");

        // Subscribe to IMU data
        imu_sub_ = nh_.subscribe("/imu/data", 50, &ImuToOdom::imuCallback, this);

        // Advertise Odometry data
        odom_pub_ = nh_.advertise<nav_msgs::Odometry>("/odom", 50);

        // Advertise Path data
        path_pub_ = nh_.advertise<nav_msgs::Path>("/path", 1, true);

        // Initialize odometry message
        odom_.header.frame_id = "odom";
        odom_.child_frame_id = "base_link";

        // Initialize path message
        path_.header.frame_id = "odom";

        // Initialize position
        x_ = 0.0;
        y_ = 0.0;
        th_ = 0.0;
        last_time_ = ros::Time::now();
    }

private:
    ros::NodeHandle nh_;
    ros::Subscriber imu_sub_;
    ros::Publisher odom_pub_;
    ros::Publisher path_pub_;
    nav_msgs::Odometry odom_;
    nav_msgs::Path path_;
    tf::TransformBroadcaster odom_broadcaster_;

    double x_, y_, th_;
    ros::Time last_time_;

    void imuCallback(const sensor_msgs::Imu::ConstPtr& msg)
    {
        // Calculate delta time
        ros::Time current_time = ros::Time::now();
        double dt = (current_time - last_time_).toSec();
        last_time_ = current_time;

        // Convert IMU orientation to Euler angles
        tf::Quaternion quat;
        tf::quaternionMsgToTF(msg->orientation, quat);
        double roll, pitch, yaw;
        tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);

        // Integrate position
        double delta_x = msg->linear_acceleration.x * dt * dt / 2;
        double delta_y = msg->linear_acceleration.y * dt * dt / 2;
        double delta_th = yaw - th_;
        th_ = yaw;

        x_ += delta_x * cos(th_) - delta_y * sin(th_);
        y_ += delta_x * sin(th_) + delta_y * cos(th_);

        // Fill in the Odometry message
        odom_.header.stamp = current_time;
        odom_.pose.pose.position.x = x_;
        odom_.pose.pose.position.y = y_;
        odom_.pose.pose.orientation = msg->orientation;
        odom_.twist.twist.angular = msg->angular_velocity;
        odom_.twist.twist.linear = msg->linear_acceleration;

        // Publish the Odometry message
        odom_pub_.publish(odom_);

        // Create and publish the transform
        geometry_msgs::TransformStamped odom_trans;
        odom_trans.header.stamp = current_time;
        odom_trans.header.frame_id = "odom";
        odom_trans.child_frame_id = "base_link";

        odom_trans.transform.translation.x = x_;
        odom_trans.transform.translation.y = y_;
        odom_trans.transform.translation.z = 0.0;
        odom_trans.transform.rotation = msg->orientation;

        odom_broadcaster_.sendTransform(odom_trans);

        // Update and publish the path
        geometry_msgs::PoseStamped pose_stamped;
        pose_stamped.header.stamp = current_time;
        pose_stamped.header.frame_id = "odom";
        pose_stamped.pose = odom_.pose.pose;

        path_.poses.push_back(pose_stamped);
        path_.header.stamp = current_time; // Make sure the path header has the correct timestamp
        path_pub_.publish(path_);
    }
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, "imu_to_odom");

    ImuToOdom imu_to_odom;

    ros::spin();

    return 0;
}
