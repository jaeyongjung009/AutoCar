#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>
#include <geometry_msgs/Quaternion.h>
#include <Eigen/Dense>
#include <std_msgs/Float64.h>
#include <fstream>
#include <sstream>

using namespace Eigen;

class ExtendedKalmanFilter {
public:
    ExtendedKalmanFilter() {
        // Initialize matrices with proper sizes
        F = MatrixXd(5, 5); // 상태 벡터 차원 5로 변경
        H = MatrixXd(3, 5); // 측정 행렬 차원 3x5로 변경
        Q = MatrixXd(5, 5); // 프로세스 노이즈
        R = MatrixXd(3, 3); // 측정 노이즈
        P = MatrixXd(5, 5); // 공분산 행렬
        x = VectorXd(5);    // 상태 벡터

        F.setIdentity();
        H << 1, 0, 0, 0, 0,
             0, 0, 1, 0, 0,
             0, 0, 0, 0, 1;

        Q << 0.01, 0, 0, 0, 0,
             0, 0.01, 0, 0, 0,
             0, 0, 0.01, 0, 0,
             0, 0, 0, 0.01, 0,
             0, 0, 0, 0, 0.01;

        R << 0.1, 0, 0,
             0, 0.1, 0,
             0, 0, 0.1;

        P.setIdentity();
        x.setZero();
    }

    void predict(const VectorXd& u, double dt) {
        // State transition function
        x[0] += x[1] * dt; // x 위치 업데이트
        x[2] += x[3] * dt; // y 위치 업데이트
        x[4] += u[1] * dt; // yaw 업데이트 (u[1]는 yaw 각속도)

        // Jacobian of the state transition function
        // 필요에 따라 F 행렬 업데이트
        F(0, 1) = dt; // x 위치에서의 속도
        F(2, 3) = dt; // y 위치에서의 속도
        F(4, 1) = dt; // yaw 각속도

        P = F * P * F.transpose() + Q; // 공분산 업데이트
    }

    void update(const VectorXd& z) {
        VectorXd y = z - H * x; // 잔여 오차 계산
        MatrixXd S = H * P * H.transpose() + R; // 공분산 행렬
        MatrixXd K = P * H.transpose() * S.inverse(); // 칼만 이득

        x = x + K * y; // 상태 벡터 업데이트
        P = (MatrixXd::Identity(5, 5) - K * H) * P; // 공분산 행렬 업데이트
    }

    VectorXd getState() const {
        return x; // 현재 상태 반환
    }

private:
    MatrixXd F; // Jacobian of the state transition function
    MatrixXd H; // Observation matrix
    MatrixXd Q; // Process noise covariance
    MatrixXd R; // Measurement noise covariance
    MatrixXd P; // Estimate covariance
    VectorXd x; // State estimate
};

class IMUToOdometry {
public:
    IMUToOdometry() : ekf() {
        imu_sub_ = nh_.subscribe("imu/data", 10, &IMUToOdometry::imuCallback, this);
        yaw_sub_ = nh_.subscribe("imu/yaw", 10, &IMUToOdometry::yawCallback, this);
        odom_pub_ = nh_.advertise<nav_msgs::Odometry>("odom", 10);

        // CSV 파일 열기
        csv_file_.open("filtered_imu_data.csv");
        if (csv_file_.is_open()) {
            csv_file_ << "timestamp,x,y,yaw,compass_yaw\n"; // CSV 헤더 업데이트
        } else {
            ROS_ERROR("CSV 파일을 열 수 없습니다.");
        }

        last_time_ = ros::Time::now();
    }

    ~IMUToOdometry() {
        if (csv_file_.is_open()) {
            csv_file_.close();
        }
    }

private:
    void imuCallback(const sensor_msgs::Imu::ConstPtr& imu_msg) {
        ros::Time current_time = ros::Time::now();
        double dt = (current_time - last_time_).toSec();

        // Control input (u)
        VectorXd u(2); // yaw 각속도를 포함한 2차원 벡터로 수정
        u << imu_msg->linear_acceleration.x * dt,
             imu_msg->angular_velocity.z; // z 방향 각속도

        ekf.predict(u, dt);

        // Measurement vector (z)
        VectorXd z(3);
        z << imu_msg->linear_acceleration.x,
             imu_msg->linear_acceleration.y,
             imu_msg->angular_velocity.z; // z 방향 각속도 사용

        ekf.update(z);

        VectorXd state = ekf.getState();
        double x = state[0];
        double y = state[2];
        double yaw = state[4]; // 필터링된 yaw 값

        // CSV 파일에 데이터 기록
        if (csv_file_.is_open()) {
            csv_file_ << current_time.toSec() << ","
                       << x << ","
                       << y << ","
                       << yaw << ","
                       << convertYawToCompass(yaw) << "\n"; // yaw 값을 나침반 각도로 변환하여 기록
        }

        // Create and publish odometry message
        nav_msgs::Odometry odom;
        odom.header.stamp = current_time;
        odom.header.frame_id = "odom";
        odom.child_frame_id = "base_link";

        odom.pose.pose.position.x = x;
        odom.pose.pose.position.y = y;
        odom.pose.pose.orientation = tf::createQuaternionMsgFromYaw(yaw); // yaw를 쿼터니언으로 변환

        odom.twist.twist.linear.x = imu_msg->linear_acceleration.x;
        odom.twist.twist.linear.y = imu_msg->linear_acceleration.y;
        odom.twist.twist.angular.z = imu_msg->angular_velocity.z;

        odom_pub_.publish(odom);

        // Broadcast transform
        tf::Transform transform;
        transform.setOrigin(tf::Vector3(x, y, 0.0));
        transform.setRotation(tf::Quaternion(
            imu_msg->orientation.x,
            imu_msg->orientation.y,
            imu_msg->orientation.z,
            imu_msg->orientation.w
        ));
        tf_broadcaster_.sendTransform(tf::StampedTransform(transform, current_time, "odom", "base_link"));

        last_time_ = current_time;
    }

    void yawCallback(const std_msgs::Float64::ConstPtr& yaw_msg) {
        VectorXd z(3);
        z << 0.0, 0.0, yaw_msg->data;
        ekf.update(z);
    }

    double convertYawToCompass(double yaw) {
        // Yaw 값을 도로 변환
        double yaw_degrees = yaw * (180.0 / M_PI);
        
        // Yaw 값을 0-360도 범위로 조정
        if (yaw_degrees < 0) {
            yaw_degrees += 360.0;
        }
        
        // 나침반 각도로 변환: 0도가 북쪽을 가리키도록 변환
        return yaw_degrees; // 기본적으로 yaw가 북쪽을 가리키는 방향에 맞춰 조정
    }

    ros::NodeHandle nh_;
    ros::Subscriber imu_sub_;
    ros::Subscriber yaw_sub_;
    ros::Publisher odom_pub_;
    tf::TransformBroadcaster tf_broadcaster_;
    ros::Time last_time_;
    ExtendedKalmanFilter ekf;
    std::ofstream csv_file_;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "imu_ekf_node");
    IMUToOdometry imu_to_odom;
    ros::spin();
    return 0;
}
