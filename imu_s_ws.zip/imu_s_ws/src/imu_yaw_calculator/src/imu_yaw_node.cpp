#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <std_msgs/Float64.h>

double yaw = 0.0;
double dt = 0.01;  // 샘플링 주기 (예: 100Hz)
double alpha = 0.98;  // Complementary Filter 비율

// 자기장 센서에서 yaw를 얻는 함수 (구현 필요)
double get_compass_yaw(const sensor_msgs::Imu::ConstPtr& msg) {
    // 여기에서 자기장 센서를 이용하여 yaw 값을 계산합니다.
    return 0.0;  // 임시 값
}

// IMU 콜백 함수
void imuCallback(const sensor_msgs::Imu::ConstPtr& msg) {
    static double last_time = 0.0;
    double current_time = ros::Time::now().toSec();
    
    
    // dt 계산
    if (last_time > 0) {
        dt = current_time - last_time;
    }
    last_time = current_time;

    // 자이로스코프 Z축 각속도
    double gyro_z = msg->angular_velocity.z;

    // Yaw 값 적분
    yaw += gyro_z * dt;

    // 자기장 센서에서 yaw 값 얻기
    double compass_yaw = get_compass_yaw(msg);

    // Complementary Filter 적용
    yaw = alpha * yaw + (1 - alpha) * compass_yaw;

    // yaw 값을 ROS 토픽으로 publish
    std_msgs::Float64 yaw_msg;
    yaw_msg.data = yaw;
    ros::NodeHandle nh;
    ros::Publisher yaw_pub = nh.advertise<std_msgs::Float64>("imu/yaw", 10);
    yaw_pub.publish(yaw_msg);

    // yaw 값을 출력 (디버그용)
    ROS_INFO("Yaw: %f", yaw);
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "imu_yaw_node");
    ros::NodeHandle nh;

    ros::Subscriber imu_sub = nh.subscribe("/imu/data", 10, imuCallback);
    
    ros::spin();
    
    return 0;
}
