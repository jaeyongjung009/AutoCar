#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <fstream>
#include <sstream>

class IMUCSVWriter {
public:
    IMUCSVWriter() {
        // ROS 노드 초기화
        ros::NodeHandle nh;

        // IMU 데이터 토픽 구독
        imu_subscriber_ = nh.subscribe("imu/data", 1, &IMUCSVWriter::imuCallback, this);

        // CSV 파일 열기
        csv_file_.open("imu_data.csv");
        if (csv_file_.is_open()) {
            // 헤더 작성
            csv_file_ << "timestamp,orientation_x,orientation_y,orientation_z,orientation_w,"
                          "angular_velocity_x,angular_velocity_y,angular_velocity_z,"
                          "linear_acceleration_x,linear_acceleration_y,linear_acceleration_z\n";
        } else {
            ROS_ERROR("CSV 파일을 열 수 없습니다.");
        }
    }

    ~IMUCSVWriter() {
        // 노드가 종료될 때 CSV 파일 닫기
        if (csv_file_.is_open()) {
            csv_file_.close();
        }
    }

private:
    ros::Subscriber imu_subscriber_; // IMU 데이터 구독자
    std::ofstream csv_file_;          // CSV 파일 스트림

    void imuCallback(const sensor_msgs::Imu::ConstPtr& msg) {
        // IMU 데이터를 CSV 파일에 기록
        if (csv_file_.is_open()) {
            std::stringstream ss;
            ss << msg->header.stamp.toSec() << ","
               << msg->orientation.x << ","
               << msg->orientation.y << ","
               << msg->orientation.z << ","
               << msg->orientation.w << ","
               << msg->angular_velocity.x << ","
               << msg->angular_velocity.y << ","
               << msg->angular_velocity.z << ","
               << msg->linear_acceleration.x << ","
               << msg->linear_acceleration.y << ","
               << msg->linear_acceleration.z << "\n";
            csv_file_ << ss.str(); // CSV 파일에 쓰기
        }
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "imu_csv_writer");
    IMUCSVWriter imu_csv_writer;

    ros::spin(); // 노드를 계속 실행
    return 0;
}
