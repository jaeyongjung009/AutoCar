import pandas as pd
import matplotlib.pyplot as plt

# CSV 파일 읽기
data = pd.read_csv('filtered_imu_data.csv')

# 데이터 확인
print(data.head())  # 데이터의 첫 몇 줄 출력

# 시각화
plt.figure(figsize=(12, 8))

# X, Y 위치 시각화
plt.subplot(3, 1, 1)
plt.plot(data['timestamp'].values, data['x'].values, label='X Position', color='r')
plt.plot(data['timestamp'].values, data['y'].values, label='Y Position', color='g')
plt.title('X and Y Position over Time')
plt.xlabel('Timestamp (s)')
plt.ylabel('Position (m)')
plt.legend()
plt.grid()

# Theta 시각화
plt.subplot(3, 1, 2)
plt.plot(data['timestamp'].values, data['yaw'].values, label='yaw (Orientation)', color='b')
plt.title('Theta (Orientation) over Time')
plt.xlabel('Timestamp (s)')
plt.ylabel('Theta (rad)')
plt.legend()
plt.grid()

# 모든 데이터 시각화
plt.subplot(3, 1, 3)
plt.plot(data['timestamp'].values, data['x'].values, label='X Position', color='r')
plt.plot(data['timestamp'].values, data['y'].values, label='Y Position', color='g')
plt.plot(data['timestamp'].values, data['yaw'].values, label='yaw', color='b')
plt.title('IMU Data over Time')
plt.xlabel('Timestamp (s)')
plt.ylabel('Value')
plt.legend()
plt.grid()

# 그래프 보여주기
plt.tight_layout()
plt.show()
