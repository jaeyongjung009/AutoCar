import pandas as pd
import matplotlib.pyplot as plt

# CSV 파일 읽기
data = pd.read_csv("imu_data.csv")

# 데이터 확인 (첫 5행 출력)
print(data.head())

# 그래프 그리기
plt.figure(figsize=(12, 8))

# 오리엔테이션 시각화
plt.subplot(3, 1, 1)
plt.plot(data['timestamp'].values, data['orientation_x'].values, label='Orientation X', color='r')
plt.plot(data['timestamp'].values, data['orientation_y'].values, label='Orientation Y', color='g')
plt.plot(data['timestamp'].values, data['orientation_z'].values, label='Orientation Z', color='b')
plt.plot(data['timestamp'].values, data['orientation_w'].values, label='Orientation W', color='y')
plt.title('IMU Orientation')
plt.xlabel('Timestamp (s)')
plt.ylabel('Orientation')
plt.legend()
plt.grid()

# 각속도 시각화
plt.subplot(3, 1, 2)
plt.plot(data['timestamp'].values, data['angular_velocity_x'].values, label='Angular Velocity X', color='r')
plt.plot(data['timestamp'].values, data['angular_velocity_y'].values, label='Angular Velocity Y', color='g')
plt.plot(data['timestamp'].values, data['angular_velocity_z'].values, label='Angular Velocity Z', color='b')
plt.title('IMU Angular Velocity')
plt.xlabel('Timestamp (s)')
plt.ylabel('Angular Velocity (rad/s)')
plt.legend()
plt.grid()

# 선형 가속도 시각화
plt.subplot(3, 1, 3)
plt.plot(data['timestamp'].values, data['linear_acceleration_x'].values, label='Linear Acceleration X', color='r')
plt.plot(data['timestamp'].values, data['linear_acceleration_y'].values, label='Linear Acceleration Y', color='g')
plt.plot(data['timestamp'].values, data['linear_acceleration_z'].values, label='Linear Acceleration Z', color='b')
plt.title('IMU Linear Acceleration')
plt.xlabel('Timestamp (s)')
plt.ylabel('Linear Acceleration (m/s²)')
plt.legend()
plt.grid()

# 그래프 표시
plt.tight_layout()
plt.show()
