#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include <cmath>

// 각도 범위 (라디안)
#define MIN_ANGLE (5*M_PI / 6) // 150도
#define MAX_ANGLE (7*M_PI / 6) // 210도

ros::Publisher filtered_scan_pub;

// 콜백 함수
void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
    // 새로운 LaserScan 메시지 생성
    sensor_msgs::LaserScan filtered_scan = *scan;
    
    // 필터링할 인덱스 계산
    int start_index = (MIN_ANGLE - scan->angle_min) / scan->angle_increment;
    int end_index = (MAX_ANGLE - scan->angle_min) / scan->angle_increment;
    
    // 유효한 인덱스 범위 확인
    if (start_index < 0) start_index = 0;
    if (end_index >= scan->ranges.size()) end_index = scan->ranges.size() - 1;
    
    // 필터링된 데이터 크기 조정
    filtered_scan.angle_min = -M_PI / 6;  // -60도
    filtered_scan.angle_max = M_PI / 6;   // 60도
    filtered_scan.angle_increment = (filtered_scan.angle_max - filtered_scan.angle_min) / (end_index - start_index + 1);
    filtered_scan.ranges.resize(end_index - start_index + 1);
    filtered_scan.intensities.resize(end_index - start_index + 1);
    
    // 데이터 복사 및 각도와 거리 출력
    for (int i = start_index; i <= end_index; i++) {
        int new_index = end_index - i;  // 데이터 순서 반전
        filtered_scan.ranges[new_index] = scan->ranges[i];
        filtered_scan.intensities[new_index] = scan->intensities[i];
        
        // 원래 각도 및 거리 계산
        float original_angle = scan->angle_min + i * scan->angle_increment;
        float distance = scan->ranges[i];
        
        // 새로운 각도 계산 (-60도에서 60도 범위로 매핑)
        float new_angle = filtered_scan.angle_min + new_index * filtered_scan.angle_increment;
        
        // 각도와 거리 출력
        ROS_INFO("Original Angle: %f rad, New Angle: %f rad, Distance: %f m", original_angle, new_angle, distance);
    }
    
    // 필터링된 데이터 발행
    filtered_scan_pub.publish(filtered_scan);
    ROS_INFO("Published filtered scan with angle range: [%f, %f]",
             filtered_scan.angle_min * 180 / M_PI, filtered_scan.angle_max * 180 / M_PI);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "my_lidar_node");
    ros::NodeHandle nh;
    
    // 필터링된 LaserScan 데이터 발행을 위한 퍼블리셔 설정
    filtered_scan_pub = nh.advertise<sensor_msgs::LaserScan>("filtered_scan", 1000);
    
    // "/scan" 토픽 구독
    ros::Subscriber scan_sub = nh.subscribe<sensor_msgs::LaserScan>("/scan", 1000, scanCallback);
    
    // 루프 속도 설정
    ros::Rate loop_rate(10);
    
    // 메인 루프
    while (ros::ok())
    {
        // 메시지 처리
        ros::spinOnce();
        // 10 Hz 루프 속도 유지
        loop_rate.sleep();
    }
    
    return 0;
}
